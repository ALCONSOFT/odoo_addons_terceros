# ©  2015-2018 Deltatech
#              Dorin Hongu <dhongu(@)gmail(.)com
# See README.rst file on addons root folder for license details

from . import stock_immediate_transfer
from . import stock_backorder_confirmation
from . import stock_quantity_history
