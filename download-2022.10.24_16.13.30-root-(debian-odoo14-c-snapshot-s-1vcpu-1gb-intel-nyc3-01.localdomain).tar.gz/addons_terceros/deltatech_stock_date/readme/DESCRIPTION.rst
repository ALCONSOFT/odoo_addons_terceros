Features:
 - The picking effective date can be changed when the picking is validated.
 - All the stock moves will have the picking's effective date.
