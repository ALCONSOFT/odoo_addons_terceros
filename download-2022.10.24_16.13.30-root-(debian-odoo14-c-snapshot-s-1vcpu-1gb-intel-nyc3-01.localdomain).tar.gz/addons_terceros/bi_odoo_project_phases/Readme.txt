
=> 13.0.0.1 : Improved an index as per odoo12 version.
